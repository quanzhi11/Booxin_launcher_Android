﻿# 时段欢迎语（测试 UI 插件）

安装后生效：主页欢迎语按本地时间显示：
- 05:00–10:59 → 早上好
- 11:00–16:59 → 中午好
- 其余时间 → 晚上好

卸载：删除应用私有目录 booxin-runtime/ui-plugins/booxin-ui-greeting
